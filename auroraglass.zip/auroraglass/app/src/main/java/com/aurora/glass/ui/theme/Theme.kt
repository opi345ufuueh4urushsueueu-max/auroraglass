package com.aurora.glass.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection

enum class AuroraThemeMode { Light, Dark, Amoled }

/** Exposes whether the user has Reduce Motion on, per spec §6/§10. */
val LocalReduceMotion = staticCompositionLocalOf { false }

private val LightScheme = lightColorScheme(
    primary = AccentDefault,
    background = LightBackground,
    surface = LightSurface,
    onBackground = LightOnBackground,
    onSurface = LightOnBackground,
    surfaceVariant = LightSurfaceGlass,
    error = ErrorColor,
)

private val DarkScheme = darkColorScheme(
    primary = AccentDefaultDark,
    background = DarkBackground,
    surface = DarkSurface,
    onBackground = DarkOnBackground,
    onSurface = DarkOnBackground,
    surfaceVariant = DarkSurfaceGlass,
    error = ErrorColor,
)

private val AmoledScheme = darkColorScheme(
    primary = AccentDefaultDark,
    background = AmoledBackground,
    surface = AmoledSurface,
    onBackground = AmoledOnBackground,
    onSurface = AmoledOnBackground,
    surfaceVariant = AmoledSurfaceGlass,
    error = ErrorColor,
)

@Composable
fun AuroraGlassTheme(
    mode: AuroraThemeMode = if (isSystemInDarkTheme()) AuroraThemeMode.Dark else AuroraThemeMode.Light,
    reduceMotion: Boolean = false,
    // Force RTL for the Persian-first layout regardless of device locale.
    // Remove this override if the app should also ship an LTR locale.
    forceRtl: Boolean = true,
    content: @Composable () -> Unit,
) {
    val colorScheme = when (mode) {
        AuroraThemeMode.Light -> LightScheme
        AuroraThemeMode.Dark -> DarkScheme
        AuroraThemeMode.Amoled -> AmoledScheme
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides if (forceRtl) LayoutDirection.Rtl else LocalLayoutDirection.current,
        LocalReduceMotion provides reduceMotion,
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = AuroraTypography,
            content = content,
        )
    }
}
