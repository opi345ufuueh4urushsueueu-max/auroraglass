package com.aurora.glass.ui.screens

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.glass.ui.components.ChatBubble
import com.aurora.glass.ui.components.ChatMessage
import com.aurora.glass.ui.components.MessageStatus
import com.aurora.glass.ui.components.glassSurface
import com.aurora.glass.ui.theme.LocalReduceMotion

private val sampleMessages = listOf(
    ChatMessage("1", "سلام! ماکت جدید رو دیدی؟", "10:02", isOutgoing = false),
    ChatMessage("2", "آره الان نگاه کردم، خیلی خوب شده 👌", "10:04", isOutgoing = true, status = MessageStatus.READ),
    ChatMessage("3", "بخش تاریک رو هنوز نهایی نکردم", "10:05", isOutgoing = false),
    ChatMessage("4", "مشکلی نیست، فردا با هم مرور می‌کنیم", "10:06", isOutgoing = true, status = MessageStatus.DELIVERED, replyToPreview = "بخش تاریک رو هنوز..."),
)

@Composable
fun ChatScreen(
    contactName: String = "تیم طراحی",
    isOnline: Boolean = true,
    messages: List<ChatMessage> = sampleMessages,
    onBack: () -> Unit = {},
    onSend: (String) -> Unit = {},
) {
    var draft by remember { mutableStateOf("") }
    val isDark = isSystemInDarkTheme()

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { ChatTopBar(contactName, isOnline, onBack) },
        bottomBar = {
            ChatInputBar(
                value = draft,
                onValueChange = { draft = it },
                onSend = {
                    if (draft.isNotBlank()) {
                        onSend(draft)
                        draft = ""
                    }
                },
            )
        },
    ) { padding ->
        LazyColumn(
            reverseLayout = true,
            contentPadding = PaddingValues(
                top = padding.calculateBottomPadding(),
                bottom = padding.calculateTopPadding() + 12.dp,
                start = 12.dp,
                end = 12.dp,
            ),
            verticalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            items(messages.reversed(), key = { it.id }) { message ->
                ChatBubble(message = message, isDarkTheme = isDark)
            }
        }
    }
}

@Composable
private fun ChatTopBar(name: String, isOnline: Boolean, onBack: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .glassSurface(shape = RoundedCornerShape(24.dp), tint = MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Filled.ArrowForward,
            contentDescription = "بازگشت",
            tint = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier
                .clip(CircleShape)
                .clickable(onClick = onBack)
                .padding(6.dp),
        )
        Spacer(Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .size(40.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
        )
        Spacer(Modifier.width(10.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(name, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onBackground, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(
                if (isOnline) "آنلاین" else "آخرین بازدید اخیراً",
                style = MaterialTheme.typography.labelSmall,
                color = if (isOnline) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            )
        }
    }
}

@Composable
private fun ChatInputBar(value: String, onValueChange: (String) -> Unit, onSend: () -> Unit) {
    val reduceMotion = LocalReduceMotion.current
    val sendScale by animateFloatAsState(
        targetValue = if (value.isNotBlank()) 1f else 0.9f,
        animationSpec = if (reduceMotion) spring(stiffness = Spring.StiffnessHigh) else spring(dampingRatio = Spring.DampingRatioMediumBouncy),
        label = "sendScale",
    )

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 10.dp)
            .glassSurface(shape = RoundedCornerShape(28.dp), tint = MaterialTheme.colorScheme.surfaceVariant, tintAlpha = 0.85f)
            .padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(
            Icons.Filled.AttachFile,
            contentDescription = "پیوست",
            tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
            modifier = Modifier.padding(6.dp),
        )
        Box(modifier = Modifier.weight(1f).padding(horizontal = 4.dp)) {
            if (value.isEmpty()) {
                Text(
                    "پیام بنویسید...",
                    style = MaterialTheme.typography.bodyLarge,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                )
            }
            BasicTextField(
                value = value,
                onValueChange = onValueChange,
                textStyle = MaterialTheme.typography.bodyLarge.copy(color = MaterialTheme.colorScheme.onBackground),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        Box(
            modifier = Modifier
                .size(40.dp)
                .scale(sendScale)
                .glassSurface(shape = CircleShape, tint = MaterialTheme.colorScheme.primary, tintAlpha = 0.95f, elevation = 4.dp)
                .clickable(onClick = onSend),
            contentAlignment = Alignment.Center,
        ) {
            Icon(
                if (value.isBlank()) Icons.Filled.Mic else Icons.Filled.Send,
                contentDescription = if (value.isBlank()) "پیام صوتی" else "ارسال",
                tint = Color.White,
                modifier = Modifier.size(18.dp),
            )
        }
    }
}
