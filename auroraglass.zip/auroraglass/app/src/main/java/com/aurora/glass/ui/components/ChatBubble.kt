package com.aurora.glass.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.aurora.glass.ui.theme.IncomingBubbleDark
import com.aurora.glass.ui.theme.IncomingBubbleLight
import com.aurora.glass.ui.theme.OutgoingBubbleGradientEnd
import com.aurora.glass.ui.theme.OutgoingBubbleGradientStart

enum class MessageStatus { SENT, DELIVERED, READ }

data class ChatMessage(
    val id: String,
    val text: String,
    val time: String,
    val isOutgoing: Boolean,
    val status: MessageStatus = MessageStatus.SENT,
    val replyToPreview: String? = null,
)

// Bubble corner radii — soft, not fully pill-shaped (spec: "not overly rounded").
private val BubbleShapeIncoming = RoundedCornerShape(
    topStart = 4.dp, topEnd = 18.dp, bottomEnd = 18.dp, bottomStart = 18.dp,
)
private val BubbleShapeOutgoing = RoundedCornerShape(
    topStart = 18.dp, topEnd = 4.dp, bottomEnd = 18.dp, bottomStart = 18.dp,
)

@Composable
fun ChatBubble(message: ChatMessage, isDarkTheme: Boolean, modifier: Modifier = Modifier) {
    val arrangement = if (message.isOutgoing) Arrangement.End else Arrangement.Start

    Row(modifier = modifier.fillMaxWidth(), horizontalArrangement = arrangement) {
        Box(
            modifier = Modifier
                .widthIn(max = 280.dp)
                .clip(if (message.isOutgoing) BubbleShapeOutgoing else BubbleShapeIncoming)
                .then(
                    if (message.isOutgoing) {
                        Modifier.background(
                            Brush.linearGradient(
                                listOf(OutgoingBubbleGradientStart, OutgoingBubbleGradientEnd),
                            ),
                        )
                    } else {
                        Modifier.glassSurface(
                            shape = if (message.isOutgoing) BubbleShapeOutgoing else BubbleShapeIncoming,
                            tint = if (isDarkTheme) IncomingBubbleDark else IncomingBubbleLight,
                            tintAlpha = if (isDarkTheme) 0.55f else 0.75f,
                            elevation = 2.dp,
                        )
                    },
                )
                .padding(horizontal = 14.dp, vertical = 10.dp),
        ) {
            Column {
                message.replyToPreview?.let { preview ->
                    Text(
                        text = preview,
                        style = MaterialTheme.typography.labelSmall,
                        color = (if (message.isOutgoing) Color.White else MaterialTheme.colorScheme.onSurface)
                            .copy(alpha = 0.7f),
                        modifier = Modifier.padding(bottom = 4.dp),
                    )
                }
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyLarge,
                    color = if (message.isOutgoing) Color.White else MaterialTheme.colorScheme.onSurface,
                )
                Row(
                    modifier = Modifier
                        .padding(top = 4.dp)
                        .align(Alignment.End),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Text(
                        text = message.time,
                        style = MaterialTheme.typography.labelSmall,
                        color = (if (message.isOutgoing) Color.White else MaterialTheme.colorScheme.onSurface)
                            .copy(alpha = 0.6f),
                    )
                    if (message.isOutgoing) {
                        Icon(
                            imageVector = if (message.status == MessageStatus.SENT) Icons.Filled.Check else Icons.Filled.DoneAll,
                            contentDescription = null,
                            tint = if (message.status == MessageStatus.READ) Color(0xFF6CF0FF) else Color.White.copy(alpha = 0.75f),
                            modifier = Modifier.padding(start = 4.dp),
                        )
                    }
                }
            }
        }
    }
}
