package com.aurora.glass.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Aurora Glass surface — used ONLY where it earns its keep (top bar, bottom
 * nav, FAB, dialogs, sheets, a few hero cards). Never applied blanket-wide.
 *
 * Real backdrop blur (sampling what's behind the surface) requires either
 * RenderEffect (API 31+, opaque windows only) or a blur-hash library such
 * as "Haze" (https://github.com/chrisbanes/haze) for cross-version support.
 * This modifier gives the tinted/translucent + soft-border/soft-shadow look
 * described in the spec and is a safe default; wire in Haze's
 * `Modifier.hazeChild` for true content-blur once the dependency is added.
 */
fun Modifier.glassSurface(
    shape: Shape = RoundedCornerShape(20.dp),
    tint: Color,
    tintAlpha: Float = 0.65f,
    borderAlpha: Float = 0.10f,
    elevation: Dp = 8.dp,
): Modifier = this
    .shadow(elevation = elevation, shape = shape, ambientColor = tint.copy(alpha = 0.15f), spotColor = tint.copy(alpha = 0.15f))
    .background(color = tint.copy(alpha = tintAlpha), shape = shape)
    .border(width = 0.75.dp, color = Color.White.copy(alpha = borderAlpha), shape = shape)

/** Optional real blur for API 31+ where a translucent window background is available. */
fun Modifier.experimentalContentBlur(radius: Dp = 18.dp): Modifier =
    this.blur(radius = radius)

/** Convenience: glass tuned to the current color scheme's surfaceVariant. */
@Composable
fun Modifier.themedGlass(
    shape: Shape = RoundedCornerShape(20.dp),
    tintAlpha: Float = 0.65f,
): Modifier = glassSurface(
    shape = shape,
    tint = MaterialTheme.colorScheme.surfaceVariant,
    tintAlpha = tintAlpha,
)
