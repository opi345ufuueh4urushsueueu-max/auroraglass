package com.aurora.glass.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.PushPin
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.aurora.glass.ui.components.glassSurface
import com.aurora.glass.ui.components.themedGlass

data class ChatSummary(
    val id: String,
    val name: String,
    val lastMessage: String,
    val time: String,
    val unreadCount: Int = 0,
    val isMuted: Boolean = false,
    val isPinned: Boolean = false,
    val avatarColor: Color,
)

private val sampleChats = listOf(
    ChatSummary("1", "تیم طراحی", "نسخه جدید ماکت رو آپلود کردم", "12:40", unreadCount = 3, isPinned = true, avatarColor = Color(0xFF6C63FF)),
    ChatSummary("2", "سارا احمدی", "باشه، فردا هماهنگ می‌کنیم", "11:05", isPinned = true, avatarColor = Color(0xFFF2B84B)),
    ChatSummary("3", "گروه خانواده", "عکس‌های مسافرت رو دیدید؟", "10:22", unreadCount = 12, isMuted = true, avatarColor = Color(0xFF34C77B)),
    ChatSummary("4", "علی رضایی", "ممنون از کمکت 🙏", "دیروز", avatarColor = Color(0xFF4FA3F7)),
    ChatSummary("5", "کانال اخبار فناوری", "پنج خبر مهم امروز در حوزه AI", "دیروز", isMuted = true, avatarColor = Color(0xFFEF5A5A)),
)

@Composable
fun HomeScreen(
    chats: List<ChatSummary> = sampleChats,
    onOpenChat: (String) -> Unit = {},
    onNewChat: () -> Unit = {},
) {
    val pinned = chats.filter { it.isPinned }
    val recent = chats.filterNot { it.isPinned }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { HomeTopBar() },
        floatingActionButton = { GlassFab(onClick = onNewChat) },
    ) { padding ->
        LazyColumn(
            contentPadding = PaddingValues(top = padding.calculateTopPadding() + 8.dp, bottom = 96.dp),
            modifier = Modifier.fillMaxSize(),
        ) {
            if (pinned.isNotEmpty()) {
                item { SectionLabel("پین‌شده") }
                items(pinned, key = { it.id }) { chat ->
                    ChatListItem(chat, onClick = { onOpenChat(chat.id) })
                }
            }
            if (recent.isNotEmpty()) {
                item { SectionLabel("اخیر") }
                items(recent, key = { it.id }) { chat ->
                    ChatListItem(chat, onClick = { onOpenChat(chat.id) })
                }
            }
        }
    }
}

@Composable
private fun HomeTopBar() {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 12.dp)
            .glassSurface(shape = RoundedCornerShape(24.dp), tint = MaterialTheme.colorScheme.surfaceVariant)
            .padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text("سلام 👋", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f))
            Text("گفتگوها", style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
        }
        Icon(
            imageVector = Icons.Filled.Search,
            contentDescription = "جستجو",
            tint = MaterialTheme.colorScheme.onBackground,
            modifier = Modifier
                .clip(CircleShape)
                .clickable { }
                .padding(8.dp),
        )
        Spacer(Modifier.width(4.dp))
        Box(
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primary),
        )
    }
}

@Composable
private fun GlassFab(onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(58.dp)
            .glassSurface(shape = CircleShape, tint = MaterialTheme.colorScheme.primary, tintAlpha = 0.9f, elevation = 10.dp)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(Icons.Filled.Add, contentDescription = "گفتگوی جدید", tint = Color.White)
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.labelLarge,
        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f),
        modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp),
    )
}

@Composable
private fun ChatListItem(chat: ChatSummary, onClick: () -> Unit) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Box(
            modifier = Modifier
                .size(52.dp)
                .clip(CircleShape)
                .background(chat.avatarColor),
            contentAlignment = Alignment.Center,
        ) {
            Text(chat.name.take(1), color = Color.White, style = MaterialTheme.typography.titleMedium)
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    chat.name,
                    style = MaterialTheme.typography.titleMedium,
                    color = MaterialTheme.colorScheme.onBackground,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.weight(1f, fill = false),
                )
                if (chat.isPinned) {
                    Icon(
                        Icons.Filled.PushPin,
                        contentDescription = "پین‌شده",
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                        modifier = Modifier.padding(start = 6.dp).size(14.dp),
                    )
                }
                if (chat.isMuted) {
                    Icon(
                        Icons.Filled.VolumeOff,
                        contentDescription = "بی‌صدا",
                        tint = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.4f),
                        modifier = Modifier.padding(start = 6.dp).size(14.dp),
                    )
                }
            }
            Text(
                chat.lastMessage,
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f),
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
        }
        Spacer(Modifier.width(8.dp))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                chat.time,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
            )
            if (chat.unreadCount > 0) {
                Box(
                    modifier = Modifier
                        .padding(top = 6.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.primary)
                        .padding(horizontal = 7.dp, vertical = 2.dp),
                ) {
                    Text(
                        chat.unreadCount.toString(),
                        style = MaterialTheme.typography.labelSmall,
                        color = Color.White,
                        fontWeight = FontWeight.Medium,
                    )
                }
            }
        }
    }
}
