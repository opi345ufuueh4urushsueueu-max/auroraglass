package com.aurora.glass.ui.theme

import androidx.compose.material3.Typography
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp

/**
 * Using the system default font family so the project builds and runs
 * immediately with no extra assets. For real Persian typography, swap
 * this for the Vazirmatn font:
 *
 * 1. Download the .ttf files: https://github.com/rastikerdar/vazirmatn
 * 2. Place them in app/src/main/res/font/ as vazirmatn_regular.ttf,
 *    vazirmatn_medium.ttf, vazirmatn_bold.ttf
 * 3. Replace the line below with:
 *
 *    import androidx.compose.ui.text.font.Font
 *    import com.aurora.glass.R
 *
 *    val AuroraFontFamily = FontFamily(
 *        Font(R.font.vazirmatn_regular, FontWeight.Normal),
 *        Font(R.font.vazirmatn_medium, FontWeight.Medium),
 *        Font(R.font.vazirmatn_bold, FontWeight.Bold),
 *    )
 */
val AuroraFontFamily = FontFamily.Default

// Hierarchy is built with WEIGHT, not color — per spec section 7.
val AuroraTypography = Typography(
    headlineSmall = TextStyle(
        fontFamily = AuroraFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 24.sp,
        lineHeight = 32.sp,
    ),
    titleLarge = TextStyle( // screen titles / chat name in top bar
        fontFamily = AuroraFontFamily,
        fontWeight = FontWeight.Bold,
        fontSize = 20.sp,
        lineHeight = 28.sp,
    ),
    titleMedium = TextStyle( // chat list item name
        fontFamily = AuroraFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 16.sp,
        lineHeight = 22.sp,
    ),
    bodyLarge = TextStyle( // message text
        fontFamily = AuroraFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 16.sp,
        lineHeight = 24.sp,
    ),
    bodyMedium = TextStyle( // last-message preview
        fontFamily = AuroraFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 14.sp,
        lineHeight = 20.sp,
    ),
    labelSmall = TextStyle( // timestamps, captions
        fontFamily = AuroraFontFamily,
        fontWeight = FontWeight.Normal,
        fontSize = 11.sp,
        lineHeight = 14.sp,
    ),
    labelLarge = TextStyle( // buttons
        fontFamily = AuroraFontFamily,
        fontWeight = FontWeight.Medium,
        fontSize = 14.sp,
        lineHeight = 20.sp,
    ),
)
