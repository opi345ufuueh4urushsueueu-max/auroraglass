package com.aurora.glass

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.aurora.glass.ui.screens.ChatScreen
import com.aurora.glass.ui.screens.HomeScreen
import com.aurora.glass.ui.screens.SplashScreen
import com.aurora.glass.ui.theme.AuroraGlassTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AuroraGlassTheme {
                AuroraGlassApp()
            }
        }
    }
}

private object Routes {
    const val Splash = "splash"
    const val Home = "home"
    const val Chat = "chat/{chatId}/{chatName}"
    fun chat(id: String, name: String) = "chat/$id/$name"
}

@Composable
fun AuroraGlassApp() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Routes.Splash,
    ) {
        composable(Routes.Splash) {
            SplashScreen(onFinished = {
                navController.navigate(Routes.Home) {
                    popUpTo(Routes.Splash) { inclusive = true }
                }
            })
        }

        composable(Routes.Home) {
            HomeScreen(
                onOpenChat = { chatId -> navController.navigate(Routes.chat(chatId, "گفتگو")) },
                onNewChat = { /* TODO: open New Chat screen */ },
            )
        }

        composable(
            route = Routes.Chat,
            enterTransition = { slideInHorizontally { it / 3 } + fadeIn() },
            exitTransition = { slideOutHorizontally { it / 3 } + fadeOut() },
        ) { backStackEntry ->
            val chatName = backStackEntry.arguments?.getString("chatName") ?: "گفتگو"
            ChatScreen(
                contactName = chatName,
                onBack = { navController.popBackStack() },
            )
        }
    }
}
