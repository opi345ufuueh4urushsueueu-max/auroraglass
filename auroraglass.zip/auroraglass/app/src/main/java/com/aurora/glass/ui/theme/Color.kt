package com.aurora.glass.ui.theme

import androidx.compose.ui.graphics.Color

/**
 * Aurora Glass — Color System
 * Single primary accent + semantic colors. No decorative color noise.
 * Accent is intentionally exposed as a top-level val so it can be made
 * user-configurable later (e.g. persisted in DataStore).
 */

// Accent (default — swap freely, everything else derives contrast from it)
val AccentDefault = Color(0xFF6C63FF)      // soft violet-indigo
val AccentDefaultDark = Color(0xFF8B82FF)  // slightly brighter for dark surfaces

// Semantic
val SuccessColor = Color(0xFF34C77B)
val WarningColor = Color(0xFFF2B84B)
val ErrorColor = Color(0xFFEF5A5A)
val InfoColor = Color(0xFF4FA3F7)

// ---------- Light ----------
val LightBackground = Color(0xFFF5F6FA)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceGlass = Color(0xFFFFFFFF) // used with alpha in GlassSurface
val LightOnBackground = Color(0xFF1C1C24)
val LightOnSurfaceSecondary = Color(0xFF6B6B78)
val LightBorder = Color(0xFF000000) // used with low alpha

// ---------- Dark ----------
val DarkBackground = Color(0xFF0F0F14)
val DarkSurface = Color(0xFF1A1A22)
val DarkSurfaceGlass = Color(0xFF2A2A35) // used with alpha in GlassSurface
val DarkOnBackground = Color(0xFFEDEDF2)
val DarkOnSurfaceSecondary = Color(0xFFA0A0AD)
val DarkBorder = Color(0xFFFFFFFF) // used with low alpha

// ---------- AMOLED ----------
val AmoledBackground = Color(0xFF000000)
val AmoledSurface = Color(0xFF000000)
val AmoledSurfaceGlass = Color(0xFF141418) // minimal, only where structurally needed
val AmoledOnBackground = Color(0xFFEDEDF2)
val AmoledOnSurfaceSecondary = Color(0xFF8E8E99)
val AmoledBorder = Color(0xFFFFFFFF)

// ---------- Chat bubbles ----------
val IncomingBubbleLight = Color(0xFFFFFFFF) // used with alpha
val IncomingBubbleDark = Color(0xFF232330)  // used with alpha
val OutgoingBubbleGradientStart = AccentDefault
val OutgoingBubbleGradientEnd = Color(0xFF8B7CFF)
