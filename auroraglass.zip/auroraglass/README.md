# Aurora Glass — نمونه اولیه (Jetpack Compose)

پیاده‌سازی اولیه‌ی سبک طراحی «Aurora Glass» روی سه صفحه‌ی کلیدی، به‌عنوان
نقطه‌ی شروع برای باقی صفحات لیست‌شده در بخش ۱۳ سند طراحی.

## ساختار

```
app/src/main/java/com/aurora/glass/
├── MainActivity.kt              # NavHost: Splash → Home → Chat
├── ui/theme/
│   ├── Color.kt                 # Light / Dark / AMOLED + رنگ‌های semantic
│   ├── Type.kt                  # Typography (نیازمند فونت Vazirmatn)
│   └── Theme.kt                 # AuroraGlassTheme + اجبار RTL + Reduce Motion
├── ui/components/
│   ├── GlassSurface.kt          # Modifier مشترک برای همه‌ی Glass Surfaceها
│   └── ChatBubble.kt            # حباب پیام ورودی/خروجی + وضعیت ارسال
└── ui/screens/
    ├── SplashScreen.kt
    ├── HomeScreen.kt            # لیست چت (پین‌شده/اخیر) + FAB شیشه‌ای
    └── ChatScreen.kt            # حباب‌ها + نوار ورودی با انیمیشن دکمه ارسال
```

## چیزهایی که همین الان کار می‌کنند

- سه تم (Light / Dark / AMOLED) از طریق `AuroraThemeMode`
- RTL به‌صورت پیش‌فرض فعال (`forceRtl = true` در `AuroraGlassTheme`)
- Glass effect محدود به جاهایی که در سند مشخص شده (top bar، FAB، bottom sheet نوار ورودی، حباب پیام ورودی) — نه همه‌جا
- Reduce Motion از طریق `LocalReduceMotion` به انیمیشن اسپلش و دکمه ارسال وصل شده
- حالت‌های خالی/بارگذاری هنوز اضافه نشده‌اند (قدم بعدی)

## چطور بازش کنی (با کامپیوتر)

1. فایل `auroraglass.zip` را از حالت فشرده خارج کن.
2. در Android Studio: `File → Open` و پوشه‌ی `auroraglass` (همونی که `settings.gradle.kts` توش هست) را انتخاب کن.
3. اگر Android Studio پیام "Gradle wrapper missing" داد، گزینه‌ی
   ساختن/دانلود خودکار wrapper را قبول کن (چون فایل باینری `gradle-wrapper.jar`
   در این خروجی قرار داده نشده).
4. صبر کن Sync تموم بشه (اولین بار چند دقیقه طول می‌کشه چون dependencyها
   دانلود می‌شن — نیاز به اینترنت داره).
5. یک Emulator با API 26+ روشن کن یا گوشی رو با USB debugging وصل کن و ▶️ Run بزن.

پروژه با فونت سیستم (System Default) از قبل کامپایل و اجرا می‌شه — نیازی به
فونت Vazirmatn برای *اجرا شدن* نیست؛ اضافه‌کردنش اختیاریه (توضیح در `Type.kt`).

## چطور فقط با گوشی اجراش کنی (بدون کامپیوتر)

پروژه شامل `.github/workflows/build.yml` است که APK رو خودکار روی سرورهای
GitHub می‌سازه — کل مراحل از توی مرورگر گوشی انجام می‌شه:

1. یک اکانت رایگان در **github.com** بساز (اگه نداری).
2. یک ریپازیتوری خالی جدید بساز (public یا private، فرقی نداره).
3. توی صفحه‌ی ریپو، از تب **Code → Codespaces → Create codespace on main**
   یک محیط VS Code آنلاین باز کن (رایگانه، نیاز به نصب چیزی روی گوشی نداره).
4. توی پنل Explorer سمت چپ Codespace، راست‌کلیک (یا لمس طولانی) کن و
   **Upload...** رو بزن، فایل `auroraglass.zip` رو از گوشی انتخاب کن.
5. توی ترمینال Codespace بنویس:
   ```
   unzip auroraglass.zip
   mv auroraglass/* auroraglass/.[!.]* . 2>/dev/null
   rm -rf auroraglass auroraglass.zip
   ```
6. از پنل **Source Control** (آیکون شاخه‌ای شکل)، تغییرات رو commit و push کن.
7. برو به تب **Actions** بالای صفحه‌ی ریپو — یک workflow به اسم
   "Build debug APK" شروع به اجرا می‌شه (چند دقیقه طول می‌کشه).
8. وقتی تیک سبز خورد، روش کلیک کن، پایین صفحه بخش **Artifacts** رو باز کن
   و `auroraglass-debug-apk` رو دانلود کن (یک فایل zip حاوی APK).
9. زیپ رو با اپ Files گوشی باز کن، روی فایل `app-debug.apk` بزن تا نصب بشه
   (اگه پرسید، اجازه‌ی "نصب از منابع ناشناس" برای مرورگر/Files بده).

## Glassmorphism واقعی (اختیاری)

`GlassSurface.kt` فعلاً افکت شیشه‌ای را با ترکیب شفافیت + border + shadow
شبیه‌سازی می‌کند (بدون بلور واقعی محتوای پشت صفحه). برای بلور واقعی، کتابخانه
[Haze](https://github.com/chrisbanes/haze) را اضافه کن و `Modifier.hazeChild`
را جایگزین بخش `background()` در `glassSurface()` کن.

## قدم‌های بعدی (طبق بخش ۱۳ سند)

Login، Verification، Search، Groups، Channels، Profile، Settings،
Media Viewer، User Profile، Group Info، Channel Info، New Chat —
همه باید از همان `GlassSurface` و `AuroraGlassTheme` استفاده کنند تا هویت
بصری یکپارچه بماند.
